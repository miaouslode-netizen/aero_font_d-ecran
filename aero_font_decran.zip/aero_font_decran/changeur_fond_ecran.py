"""
Changeur de fond d'écran (Windows)
----------------------------------
- Tourne en arrière-plan (icône près de l'horloge, sous la flèche ^)
- Se lance tout seul au démarrage de Windows
- Change le fond selon l'intervalle choisi (hasard ou ordre)
- Vrai fondu fluide (fenêtre posée derrière les icônes, alpha géré par
  la carte graphique), glissement, ou aléatoire
- Très léger : aucune boucle active, priorité basse, mémoire libérée
- Onglet Réglages : démarrage auto, durée d'animation, désinstallation
"""

import os
import sys
import gc
import json
import time
import shutil
import random
import ctypes
from ctypes import wintypes
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from PIL import Image, ImageOps, ImageDraw

try:
    import pystray
except ImportError:
    pystray = None

# ------------------------------------------------------------ constantes ---

NOM = "ChangeurFondEcran"
DATA = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), NOM)
CACHE = os.path.join(DATA, "cache")
CONFIG = os.path.join(DATA, "config.json")
EXE_INSTALLE = os.path.join(DATA, NOM + ".exe")
FROZEN = getattr(sys, "frozen", False)
EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp", ".webp")
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

DEFAUT = dict(dossier="", mode="hasard", anim="fondu", valeur=10,
              unite="minutes", duree_anim=1.0, demarrage=True,
              actif=False, index=-1, fond_actuel="")

ANIMS = {"Fondu": "fondu", "Glissement": "glissement",
         "Aléatoire": "aleatoire", "Aucune": "aucune"}
ANIMS_INV = {v: k for k, v in ANIMS.items()}
UNITES = {"secondes": 1, "minutes": 60, "heures": 3600}

_mutex = None


# --------------------------------------------------------------- config ---

def charger_config():
    cfg = dict(DEFAUT)
    try:
        with open(CONFIG, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def sauver_config(cfg):
    try:
        os.makedirs(DATA, exist_ok=True)
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ------------------------------------------------------------- Windows ---

def instance_unique():
    """False si l'application tourne déjà."""
    global _mutex
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateMutexW.restype = ctypes.c_void_p
    _mutex = k.CreateMutexW(None, False, NOM + "_mutex")
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS


def basse_priorite():
    """Priorité basse : l'appli ne gêne jamais le PC."""
    try:
        k = ctypes.WinDLL("kernel32")
        k.GetCurrentProcess.restype = ctypes.c_void_p
        k.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        k.SetPriorityClass(k.GetCurrentProcess(), 0x00004000)  # BELOW_NORMAL
    except Exception:
        pass


def dpi_et_taille():
    u = ctypes.windll.user32
    try:
        u.SetProcessDPIAware()
    except Exception:
        pass


def taille_ecran():
    u = ctypes.windll.user32
    return u.GetSystemMetrics(0), u.GetSystemMetrics(1)


def definir_fond(chemin, definitif):
    # 2 = envoyer le changement (rapide, pour l'animation)
    # 3 = envoyer + mémoriser (pour l'image finale)
    ctypes.windll.user32.SystemParametersInfoW(
        20, 0, chemin, 3 if definitif else 2)


def regler_style_fond():
    """Style 'Remplir' pour que l'image couvre tout l'écran."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop",
                            0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, "WallpaperStyle", 0, winreg.REG_SZ, "10")
            winreg.SetValueEx(k, "TileWallpaper", 0, winreg.REG_SZ, "0")
    except Exception:
        pass


def fond_systeme():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Control Panel\Desktop") as k:
            return winreg.QueryValueEx(k, "WallPaper")[0]
    except Exception:
        return ""


_u = None


def api():
    """user32 avec les bons types (indispensable en 64 bits)."""
    global _u
    if _u:
        return _u
    u = ctypes.WinDLL("user32", use_last_error=True)
    H = wintypes.HWND
    u.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    u.FindWindowW.restype = H
    u.FindWindowExW.argtypes = [H, H, wintypes.LPCWSTR, wintypes.LPCWSTR]
    u.FindWindowExW.restype = H
    u.SendMessageTimeoutW.argtypes = [H, wintypes.UINT, wintypes.WPARAM,
                                      wintypes.LPARAM, wintypes.UINT,
                                      wintypes.UINT,
                                      ctypes.POINTER(wintypes.DWORD)]
    u.SendMessageTimeoutW.restype = wintypes.LPARAM
    u.EnumWindows.argtypes = [ctypes.c_void_p, wintypes.LPARAM]
    u.EnumWindows.restype = wintypes.BOOL
    u.SetParent.argtypes = [H, H]
    u.SetParent.restype = H
    u.GetParent.argtypes = [H]
    u.GetParent.restype = H
    u.GetWindowLongW.argtypes = [H, ctypes.c_int]
    u.GetWindowLongW.restype = ctypes.c_long
    u.SetWindowLongW.argtypes = [H, ctypes.c_int, ctypes.c_long]
    u.SetWindowLongW.restype = ctypes.c_long
    u.SetWindowPos.argtypes = [H, H, ctypes.c_int, ctypes.c_int,
                               ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u.SetWindowPos.restype = wintypes.BOOL
    u.SetLayeredWindowAttributes.argtypes = [H, wintypes.DWORD,
                                             ctypes.c_ubyte, wintypes.DWORD]
    u.SetLayeredWindowAttributes.restype = wintypes.BOOL
    _u = u
    return u


def s32(v):
    return ctypes.c_long(v & 0xFFFFFFFF).value


def trouver_workerw():
    """Fenêtre 'WorkerW' située DERRIÈRE les icônes du bureau.
    Y poser notre fenêtre = l'animation passe sous les icônes et les
    fenêtres, comme le fait un vrai fond d'écran animé."""
    try:
        u = api()
        progman = u.FindWindowW("Progman", None)
        if not progman:
            return None
        res = wintypes.DWORD()
        u.SendMessageTimeoutW(progman, 0x052C, 0, 0, 0, 1000,
                              ctypes.byref(res))
        # Windows 11 récent : WorkerW est enfant de Progman
        w = u.FindWindowExW(progman, None, "WorkerW", None)
        if w:
            return w
        # Windows 10 / Windows 11 plus ancien
        trouve = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND,
                                   wintypes.LPARAM)

        def cb(hwnd, lp):
            if u.FindWindowExW(hwnd, None, "SHELLDLL_DefView", None):
                x = u.FindWindowExW(None, hwnd, "WorkerW", None)
                if x:
                    trouve.append(x)
            return True

        u.EnumWindows(proto(cb), 0)
        return trouve[0] if trouve else None
    except Exception:
        return None


def installer_exe():
    """Copie l'exe dans le dossier d'installation (pour qu'on puisse
    déplacer ou supprimer l'original sans casser le démarrage auto)."""
    try:
        src = os.path.abspath(sys.executable)
        if src.lower() == EXE_INSTALLE.lower():
            return
        if (not os.path.exists(EXE_INSTALLE)
                or os.path.getsize(EXE_INSTALLE) != os.path.getsize(src)):
            os.makedirs(DATA, exist_ok=True)
            shutil.copy2(src, EXE_INSTALLE)
    except OSError:
        pass


def commande_demarrage():
    if FROZEN:
        exe = EXE_INSTALLE if os.path.exists(EXE_INSTALLE) else sys.executable
        return f'"{exe}" --background'
    pyw = sys.executable.replace("python.exe", "pythonw.exe")
    return f'"{pyw}" "{os.path.abspath(__file__)}" --background'


def regler_demarrage(actif):
    try:
        import winreg
        if actif:
            if FROZEN:
                installer_exe()
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                                winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, NOM, 0, winreg.REG_SZ,
                                  commande_demarrage())
        else:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                                winreg.KEY_SET_VALUE) as k:
                try:
                    winreg.DeleteValue(k, NOM)
                except FileNotFoundError:
                    pass
    except Exception:
        pass


# --------------------------------------------------------------- images ---

def lister(dossier):
    try:
        return sorted((os.path.join(dossier, n) for n in os.listdir(dossier)
                       if n.lower().endswith(EXTENSIONS)), key=str.lower)
    except OSError:
        return []


def charger_image(chemin, taille):
    with Image.open(chemin) as img:
        if img.format == "JPEG":
            img.draft("RGB", taille)   # décodage réduit = rapide + peu de RAM
        img = ImageOps.exif_transpose(img).convert("RGB")
    return ImageOps.fit(img, taille, Image.LANCZOS)


def ease(t):
    return t * t * (3 - 2 * t)         # départ et arrivée en douceur


def t_fondu(a, b, t):
    return Image.blend(a, b, t)


def t_glissement(a, b, t):
    w, h = a.size
    d = int(w * t)
    f = Image.new("RGB", (w, h))
    f.paste(a, (-d, 0))
    f.paste(b, (w - d, 0))
    return f


TRANSITIONS = {"fondu": t_fondu, "glissement": t_glissement}


def icone_tray():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((4, 8, 60, 56), 8, fill=(40, 110, 220, 255))
    d.ellipse((38, 16, 50, 28), fill=(255, 230, 120, 255))
    d.polygon([(8, 52), (24, 28), (36, 44), (44, 36), (56, 52)],
              fill=(255, 255, 255, 255))
    return img


# ------------------------------------------------------------ application ---

class App:
    def __init__(self, root, arriere_plan):
        self.root = root
        self.cfg = charger_config()
        self.actif = False
        self.tache = None
        self.delai_courant = None
        self.verrou = threading.Lock()
        self.historique = []
        self.pos = -1
        self.sac = []
        self.dernier = None
        self.n = int(time.time()) % 10**8
        self.fond_actuel = self.cfg.get("fond_actuel") or None
        self.tray = None
        self.prevenu = False
        self.overlay = None

        os.makedirs(CACHE, exist_ok=True)
        regler_style_fond()
        regler_demarrage(self.cfg["demarrage"])

        root.title("Changeur de fond d'écran")
        root.geometry("500x420")
        root.resizable(False, False)
        root.protocol("WM_DELETE_WINDOW", self.cacher)
        self.construire_ui()
        self.creer_tray()

        if self.cfg["actif"] and lister(self.cfg["dossier"]):
            self.actif = True
            root.after(4000, lambda: self.changer_async(1))
        self.maj_ui()

        if arriere_plan and self.actif:
            root.withdraw()

    # ------------------------------------------------------- interface ---
    def construire_ui(self):
        c = self.cfg
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=8, pady=8)
        p1 = ttk.Frame(nb, padding=14)
        p2 = ttk.Frame(nb, padding=14)
        nb.add(p1, text="  Principal  ")
        nb.add(p2, text="  Réglages  ")

        self.v_dossier = tk.StringVar(value=c["dossier"] or "Aucun dossier choisi")
        self.v_mode = tk.StringVar(value=c["mode"])
        self.v_anim = tk.StringVar(value=ANIMS_INV.get(c["anim"], "Fondu"))
        self.v_valeur = tk.StringVar(value=str(c["valeur"]))
        self.v_unite = tk.StringVar(value=c["unite"])
        self.v_duree = tk.StringVar(value=str(c["duree_anim"]))
        self.v_demarrage = tk.BooleanVar(value=c["demarrage"])
        self.statut = tk.StringVar(value="Prêt.")

        # --- onglet principal
        ttk.Button(p1, text="📁  Choisir un dossier d'images",
                   command=self.choisir_dossier).pack(fill="x")
        ttk.Label(p1, textvariable=self.v_dossier, foreground="#666",
                  wraplength=450).pack(anchor="w", pady=(4, 12))

        l = ttk.Frame(p1); l.pack(fill="x", pady=3)
        ttk.Label(l, text="Ordre :", width=14).pack(side="left")
        ttk.Radiobutton(l, text="Au hasard", variable=self.v_mode,
                        value="hasard").pack(side="left")
        ttk.Radiobutton(l, text="Dans l'ordre", variable=self.v_mode,
                        value="ordre").pack(side="left", padx=10)

        l = ttk.Frame(p1); l.pack(fill="x", pady=3)
        ttk.Label(l, text="Animation :", width=14).pack(side="left")
        ttk.Combobox(l, textvariable=self.v_anim, state="readonly", width=14,
                     values=list(ANIMS)).pack(side="left")

        l = ttk.Frame(p1); l.pack(fill="x", pady=3)
        ttk.Label(l, text="Changer toutes les", width=14).pack(side="left")
        ttk.Spinbox(l, from_=1, to=999, width=6,
                    textvariable=self.v_valeur).pack(side="left")
        ttk.Combobox(l, textvariable=self.v_unite, state="readonly", width=9,
                     values=list(UNITES)).pack(side="left", padx=6)

        b = ttk.Frame(p1); b.pack(fill="x", pady=(16, 4))
        ttk.Button(b, text="⏮  Précédente",
                   command=self.precedente).pack(side="left", expand=True,
                                                 fill="x", padx=(0, 4))
        ttk.Button(b, text="⏭  Changer maintenant",
                   command=self.suivante).pack(side="left", expand=True,
                                               fill="x", padx=(4, 0))
        self.btn_toggle = ttk.Button(p1, text="▶  Démarrer",
                                     command=self.basculer)
        self.btn_toggle.pack(fill="x", pady=4)
        ttk.Label(p1, textvariable=self.statut, foreground="#2a6",
                  wraplength=450).pack(anchor="w", pady=(8, 0))

        # --- onglet réglages
        ttk.Checkbutton(p2, text="Lancer au démarrage de Windows "
                        "(en arrière-plan)", variable=self.v_demarrage,
                        command=self.maj_demarrage).pack(anchor="w")
        l = ttk.Frame(p2); l.pack(fill="x", pady=12)
        ttk.Label(l, text="Durée de l'animation (s) :").pack(side="left")
        ttk.Spinbox(l, from_=0.3, to=5, increment=0.1, width=6,
                    textvariable=self.v_duree).pack(side="left", padx=8)
        ttk.Label(p2, foreground="#666", wraplength=450, text=(
            "Quand tu fermes la fenêtre, l'application continue en arrière-"
            "plan : cherche son icône près de l'horloge (flèche ^).")
                  ).pack(anchor="w", pady=(0, 20))
        ttk.Separator(p2).pack(fill="x", pady=6)
        ttk.Button(p2, text="🗑  Désinstaller l'application…",
                   command=self.desinstaller).pack(anchor="w", pady=8)

        for v in (self.v_mode, self.v_anim, self.v_valeur, self.v_unite,
                  self.v_duree):
            v.trace_add("write", self.sync)

    def msg(self, texte):
        try:
            self.root.after(0, lambda: self.statut.set(texte))
        except Exception:
            pass

    def maj_ui(self):
        self.btn_toggle.config(text="⏸  Pause" if self.actif else "▶  Démarrer")
        if self.tray:
            try:
                self.tray.update_menu()
            except Exception:
                pass

    # -------------------------------------------------------- réglages ---
    def delai_s(self):
        return max(5, self.cfg["valeur"] * UNITES.get(self.cfg["unite"], 60))

    def sync(self, *_):
        try:
            valeur = max(1, int(float(self.v_valeur.get())))
            duree = min(max(float(self.v_duree.get()), 0.2), 5.0)
        except (tk.TclError, ValueError):
            return
        self.cfg.update(mode=self.v_mode.get(),
                        anim=ANIMS.get(self.v_anim.get(), "fondu"),
                        valeur=valeur, unite=self.v_unite.get(),
                        duree_anim=duree)
        sauver_config(self.cfg)
        if self.delai_s() != self.delai_courant:
            self.planifier()

    def maj_demarrage(self):
        self.cfg["demarrage"] = self.v_demarrage.get()
        sauver_config(self.cfg)
        regler_demarrage(self.cfg["demarrage"])

    def choisir_dossier(self):
        d = filedialog.askdirectory(title="Dossier contenant les images")
        if not d:
            return
        n = len(lister(d))
        if not n:
            messagebox.showwarning("Aucune image",
                                   "Ce dossier ne contient aucune image.")
            return
        self.cfg.update(dossier=d, index=-1)
        self.sac, self.historique, self.pos = [], [], -1
        sauver_config(self.cfg)
        self.v_dossier.set(f"{d}  ({n} images)")
        self.statut.set("Dossier chargé. Clique sur Démarrer.")

    # --------------------------------------------------------- planning ---
    def planifier(self):
        """Un seul minuteur Tk : zéro CPU entre deux changements."""
        if self.tache:
            self.root.after_cancel(self.tache)
            self.tache = None
        self.delai_courant = self.delai_s()
        if self.actif:
            ms = min(int(self.delai_courant * 1000), 2_000_000_000)
            self.tache = self.root.after(ms, self.tick)

    def tick(self):
        self.tache = None
        self.changer_async(1)

    def basculer(self):
        if not self.actif:
            if not lister(self.cfg["dossier"]):
                messagebox.showinfo("Dossier manquant",
                                    "Choisis d'abord un dossier d'images.")
                return
            self.actif = True
            self.changer_async(1)
        else:
            self.actif = False
            self.statut.set("En pause.")
        self.cfg["actif"] = self.actif
        sauver_config(self.cfg)
        self.planifier()
        self.maj_ui()

    def suivante(self):
        if not lister(self.cfg["dossier"]):
            messagebox.showinfo("Dossier manquant",
                                "Choisis d'abord un dossier d'images.")
            return
        self.changer_async(1)

    def precedente(self):
        self.changer_async(-1)

    # -------------------------------------------------------- changement ---
    def changer_async(self, sens):
        threading.Thread(target=self._travail, args=(sens,),
                         daemon=True).start()

    def _travail(self, sens):
        if self.verrou.acquire(blocking=False):
            try:
                self.changer(sens)
            except Exception as e:
                self.msg(f"Erreur : {e}")
            finally:
                self.verrou.release()
                gc.collect()
        try:
            self.root.after(0, self.planifier)
        except Exception:
            pass

    def prochaine(self, fichiers):
        if self.cfg["mode"] == "ordre":
            i = (self.cfg["index"] + 1) % len(fichiers)
            self.cfg["index"] = i
            return fichiers[i]
        self.sac = [f for f in self.sac if f in fichiers]
        if not self.sac:
            self.sac = fichiers[:]
            random.shuffle(self.sac)
            if len(self.sac) > 1 and self.sac[-1] == self.dernier:
                self.sac[0], self.sac[-1] = self.sac[-1], self.sac[0]
        return self.sac.pop()

    def changer(self, sens):
        cfg = dict(self.cfg)
        fichiers = lister(cfg["dossier"])
        if not fichiers:
            self.msg("Aucune image dans le dossier.")
            return

        if sens < 0:
            if self.pos <= 0:
                self.msg("Pas d'image précédente.")
                return
            self.pos -= 1
            chemin = self.historique[self.pos]
        elif self.pos < len(self.historique) - 1:
            self.pos += 1
            chemin = self.historique[self.pos]
        else:
            chemin = self.prochaine(fichiers)
            self.historique = (self.historique + [chemin])[-50:]
            self.pos = len(self.historique) - 1
        self.dernier = chemin

        taille = taille_ecran()
        nouvelle = charger_image(chemin, taille)

        nom = cfg["anim"]
        if nom == "aleatoire":
            nom = random.choice(list(TRANSITIONS))
        elif nom not in TRANSITIONS and nom != "aucune":
            nom = "fondu"
        duree = max(0.2, float(cfg["duree_anim"]))

        if nom in TRANSITIONS:
            # vrai fondu : fenêtre fluide dont l'opacité est gérée par
            # la carte graphique ; sinon ancienne méthode image par image
            if not self.animer_overlay(nouvelle, nom, duree):
                self.animation_secours(nom, nouvelle, taille, duree)

        self.afficher(nouvelle, definitif=True)   # fond réel, sous la fenêtre
        try:
            self.root.after(300, self.fermer_overlay)
        except Exception:
            pass
        self.cfg["fond_actuel"] = self.fond_actuel
        sauver_config(self.cfg)
        self.msg(f"Fond actuel : {os.path.basename(chemin)}")

    def jouer(self, fonction, a, b, duree):
        t0 = time.monotonic()
        while True:
            t = (time.monotonic() - t0) / duree
            if t >= 1:
                break
            self.afficher(fonction(a, b, ease(t)), definitif=False)

    # ---------------------------------------------- vrai fondu (overlay) ---
    def animer_overlay(self, nouvelle, mode, duree):
        """Appelé depuis le thread de travail ; attend la fin de l'animation
        (qui, elle, tourne dans le thread Tk). Renvoie False si échec."""
        fin = threading.Event()
        erreur = []

        def go():
            try:
                self.demarrer_overlay(nouvelle, mode, duree, fin.set)
            except Exception as e:
                erreur.append(e)
                self.fermer_overlay()
                fin.set()

        self.root.after(0, go)
        fin.wait(duree + 8)
        return not erreur and fin.is_set()

    def demarrer_overlay(self, img, mode, duree, fini):
        from PIL import ImageTk
        w, h = img.size
        x0 = w if mode == "glissement" else 0

        top = tk.Toplevel(self.root)
        self.overlay = top
        top.overrideredirect(True)
        top.configure(bg="black")
        if mode == "fondu":
            top.attributes("-alpha", 0.0)       # invisible au départ
        top.geometry(f"{w}x{h}+{x0}+0")
        photo = ImageTk.PhotoImage(img)
        lab = tk.Label(top, image=photo, bd=0, highlightthickness=0)
        lab.image = photo
        lab.place(x=0, y=0, width=w, height=h)
        top.update()

        u = api()
        inner = top.winfo_id()
        hwnd = u.GetParent(inner) or inner
        ex = u.GetWindowLongW(hwnd, -20)        # GWL_EXSTYLE
        # sans focus, sans bouton dans la barre, insensible à la souris
        u.SetWindowLongW(hwnd, -20, s32(ex | 0x08000000 | 0x80 | 0x20))

        workerw = trouver_workerw()
        base = 0x10 | 0x40                      # NOACTIVATE | SHOWWINDOW
        if workerw:
            u.SetParent(hwnd, workerw)          # derrière les icônes
            st = u.GetWindowLongW(hwnd, -16) & 0xFFFFFFFF
            st = (st & ~0x80000000) | 0x40000000   # POPUP -> CHILD
            u.SetWindowLongW(hwnd, -16, s32(st))
            u.SetWindowPos(hwnd, None, x0, 0, w, h, base | 0x4 | 0x20)
            if mode == "fondu" and not u.SetLayeredWindowAttributes(
                    hwnd, 0, 0, 2):
                raise RuntimeError("transparence non supportée")
        else:
            u.SetWindowPos(hwnd, 1, x0, 0, w, h, base)   # tout en bas

        t0 = time.monotonic()

        def pas():
            try:
                t = min(1.0, (time.monotonic() - t0) / duree)
                e = ease(t)
                if mode == "fondu":
                    top.attributes("-alpha", e)
                else:
                    u.SetWindowPos(hwnd, None, int(w * (1 - e)), 0, 0, 0,
                                   0x1 | 0x4 | 0x10)
                if t < 1.0:
                    self.root.after(8, pas)
                else:
                    fini()
            except Exception:
                fini()

        pas()

    def fermer_overlay(self):
        top, self.overlay = self.overlay, None
        if top is not None:
            try:
                top.destroy()
            except Exception:
                pass

    def animation_secours(self, nom, nouvelle, taille, duree):
        """Ancienne méthode image par image, si la fenêtre fluide échoue."""
        ancienne = None
        for src in (self.fond_actuel, fond_systeme()):
            if src and os.path.isfile(src):
                try:
                    ancienne = charger_image(src, taille)
                    break
                except Exception:
                    pass
        if ancienne is not None:
            self.jouer(TRANSITIONS[nom], ancienne, nouvelle, duree)

    def afficher(self, img, definitif):
        self.n += 1
        if definitif:
            chemin = os.path.join(CACHE, f"fond_{self.n}.jpg")
            img.save(chemin, "JPEG", quality=95)
            self.fond_actuel = chemin
        else:
            chemin = os.path.join(CACHE, f"anim_{self.n}.bmp")
            img.save(chemin, "BMP")
        definir_fond(chemin, definitif)
        garder = {chemin, self.fond_actuel}
        try:
            for nom in os.listdir(CACHE):
                p = os.path.join(CACHE, nom)
                if p not in garder:
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        except OSError:
            pass

    # ------------------------------------------- arrière-plan / quitter ---
    def creer_tray(self):
        if pystray is None:
            return
        menu = pystray.Menu(
            pystray.MenuItem("Ouvrir", lambda i, m: self.root.after(
                0, self.montrer), default=True),
            pystray.MenuItem("Image suivante", lambda i, m: self.root.after(
                0, self.suivante)),
            pystray.MenuItem(
                lambda item: "Pause" if self.actif else "Reprendre",
                lambda i, m: self.root.after(0, self.basculer)),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quitter", lambda i, m: self.root.after(
                0, self.quitter)))
        self.tray = pystray.Icon(NOM, icone_tray(),
                                 "Changeur de fond d'écran", menu)
        self.tray.run_detached()

    def montrer(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def cacher(self):
        if self.tray:
            self.root.withdraw()
            if not self.prevenu:
                self.prevenu = True
                try:
                    self.tray.notify("Je continue en arrière-plan. "
                                     "Clic droit sur l'icône pour quitter.",
                                     "Changeur de fond d'écran")
                except Exception:
                    pass
        else:
            self.root.iconify()

    def quitter(self):
        self.fermer_overlay()
        try:
            if self.tray:
                self.tray.stop()
        except Exception:
            pass
        self.root.destroy()

    def desinstaller(self):
        if not messagebox.askyesno(
                "Désinstaller",
                "Supprimer l'application, ses réglages et le démarrage "
                "automatique ?\n\nTon fond d'écran actuel sera conservé "
                "dans Images.", icon="warning"):
            return
        self.actif = False
        regler_demarrage(False)

        # garder le fond actuel pour ne pas se retrouver avec un écran noir
        try:
            if self.fond_actuel and os.path.isfile(self.fond_actuel):
                dest = os.path.join(os.path.expanduser("~"), "Pictures",
                                    "dernier_fond_ecran.jpg")
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy2(self.fond_actuel, dest)
                definir_fond(dest, True)
        except Exception:
            pass

        if FROZEN:
            cmd = (f'ping 127.0.0.1 -n 4 >nul & del /f /q "{sys.executable}"'
                   f' & rmdir /s /q "{DATA}"')
            subprocess.Popen(f'cmd /s /c "{cmd}"', close_fds=True,
                             creationflags=0x08000000 | 0x00000008)
        else:
            shutil.rmtree(DATA, ignore_errors=True)

        messagebox.showinfo("Désinstallé",
                            "L'application a été désinstallée.")
        self.quitter()


# ------------------------------------------------------------------ main ---

def main():
    if not sys.platform.startswith("win"):
        print("Cette application fonctionne sous Windows uniquement.")
        return
    arriere_plan = "--background" in sys.argv
    dpi_et_taille()

    if not instance_unique():
        if not arriere_plan:
            r = tk.Tk(); r.withdraw()
            messagebox.showinfo(
                NOM, "L'application tourne déjà.\nCherche son icône près "
                "de l'horloge (flèche ^).")
        return

    basse_priorite()
    root = tk.Tk()
    App(root, arriere_plan)
    root.mainloop()


if __name__ == "__main__":
    main()
